Locales['en'] = {
  ['press_to_open'] = 'Press ~INPUT_CONTEXT~ to open the shop.',
	['press_to_rob'] = 'Press ~INPUT_CONTEXT~ to ~r~rob ~w~the shop.',
	['press_to_open_center'] = 'Press ~INPUT_CONTEXT~ to open the shopcenter.',
	['name_shop'] = 'What whould you like to name your shop to?',
	['buy_shop'] = 'Buy shop ',
	['robbery_cancel'] = '~r~The robbery was canceled (you went too far)',
	['set_price'] = 'Set price on what you want to sell.',
	['how_much'] = 'How much whould you like to sell?',
}
